# Max K Media website, November 2026 build

Two folders:

- `site/` is the finished website. Deploy this.
- `generator/` is the source that wrote it. Keep it; you only need it to change something.

`SEO-HANDOVER.md` covers what the SEO work includes, what was measured, what to check in the copy and what only you can do.

## Deploy to GitHub Pages (repo `yherhr/Max-Portfolio`)

**This package replaces the whole repo.** The September brand package was a merge-only drop-in. This one is the opposite: it contains every page, all 204 `/services/` addresses, the images, favicons, `CNAME`, `.nojekyll` and its own deploy workflow. Nothing from the old site needs to survive.

```
git checkout main            # or whichever branch Pages publishes from
git pull
git tag before-nov-2026      # a way back
git rm -r -q .               # clear the tracked files
cp -r /path/to/site/. .      # the trailing /. copies the hidden files too
git add -A
git commit -m "New site, November 2026"
git push
```

On Windows without Git Bash, do the same in File Explorer: delete everything in the repo folder except `.git`, copy the contents of `site/` in (turn on "show hidden items" so `.github` and `.nojekyll` come across), then commit and push.

What changes on the server:

- The old `css/`, `js/`, `assets/`, `tools/`, `img/gallery/`, `img/work/` and the old workflow are gone. The new workflow (`.github/workflows/pages.yml`) uploads the repo as committed and runs on a push to `main` or `master`. It has no build step, so nothing regenerates the sitemap or restamps files behind your back.
- `img/sig/` is kept, so the email signature keeps loading its wordmark and icons.

### Check after the deploy

1. `https://maxkmedia.com/` loads with the favicon in the tab.
2. `https://maxkmedia.com/services/seo-parkes.html` lands on the Orange SEO page (a retired address redirecting).
3. `https://maxkmedia.com/nothing-here` shows the styled 404.
4. Send yourself an enquiry from the contact page. The form posts to Web3Forms with the existing key. I tested it against a mocked endpoint only, because the sandbox cannot reach Web3Forms.
5. In the repo's Settings, Pages: the custom domain field should read `maxkmedia.com`. A committed `CNAME` is ignored when Pages publishes from a workflow, so the field is what counts. Once it is set, `yherhr.github.io/Max-Portfolio/` should redirect to the domain.

### Tell the search engines

- Google Search Console: submit `https://maxkmedia.com/sitemap.xml`, then use URL Inspection on the home page and request indexing.
- Bing: once the site is live, run `python3 generator/indexnow.py`. It submits every sitemap URL through IndexNow. The key file is already published at the site root.

## Preview locally

Open `site/index.html` straight from the folder, or run `python3 -m http.server` inside `site/`. All links and assets are relative to each page, so both work, as does a GitHub Pages sub-path. The 404 page is the one exception: it resolves from the domain root by design.

## Changing things

Needs Python 3.12 or newer and Pillow 11.3 or newer (for AVIF).

```
cd generator
python3 build.py          # rebuild site/
python3 check.py          # links, legacy addresses, titles, schema, images
python3 sweep.py          # browser sweep at 14 widths (needs Playwright)
python3 build.py --og     # also re-render the share images (needs Playwright)
```

| To change | Edit |
|---|---|
| Phone, email, ABN, social links, hourly rate | `config.py` (`web_rate = None` removes every price mention) |
| Town facts, distances, the retired-town redirect map | `config.py` |
| Page copy | `content/core.py`, `services.py`, `photo.py`, `work.py`, `guides.py` |
| Photos | Drop the file in `photos_src/`, add one line to `content/photos.py`, rebuild |
| Colours, type, layout | `static/css/site.css` |
| Search Console or Bing verification tags | `config.py` (DNS verification at Cloudflare is simpler) |

Notes:

- The stylesheet is minified and inlined into every page. That removes a render-blocking request, and it means a cached stylesheet can never be out of step with the HTML. The one external script still carries a content hash (`js/site.js?v=...`).
- `build.py` stamps every page with `build_date` from `config.py`. Change it when you make a real content update so `lastmod` in the sitemap stays honest.
- `legacy-urls.txt` is the 210-address list from the old sitemap. `check.py` fails if any of them stops resolving.
- `docs/` holds `BRAND.md` and the email signature from the September package. They are not published.
